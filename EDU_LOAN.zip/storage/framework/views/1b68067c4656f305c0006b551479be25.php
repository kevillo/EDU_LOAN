<!-- contenido para crear el curso -->



<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="<?php echo e(asset('../resources/css/usuarios/index.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title'); ?>
<title>crear curso</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<!-- contenido para crear el curso -->
<div class="container">
    <form action="<?php echo e(route('cursos.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        

        <div class="form-group">
            <label for="nombre_curso">Nombre del curso:</label>
            <input type="text" name="nombre_curso" id="nombre_curso" class="form-control"></input>
        </div>
        <br>
        <!--Datos de bitacora-->
        <input type="hidden" id="tabla" name="tabla" value="curso">
        <input type="hidden" id="cambio" name="cambio" value="crear">
        <button type="submit" class="btn btn-primary">Guardar curso</button>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\EDU_LOAN\resources\views/cursos/create.blade.php ENDPATH**/ ?>