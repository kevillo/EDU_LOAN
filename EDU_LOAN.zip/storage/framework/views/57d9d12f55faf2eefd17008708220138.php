

<?php $__env->startSection('title'); ?>
<title>Registro de Equipos</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <h2 class="mt-4 mb-4">Registro de Equipos</h2>

    <form action="<?php echo e(route('equipos.store')); ?>" method="post" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <div class="row">
            <div class="col-md-3 text-center mb-4">
                <img src="../../resources/img/icon-equipo.png" alt="Icono de Equipos" class="img-fluid">
            </div>

            <div class="col-md-9">


                <!-- Número de serie -->
                <div class="mb-3">
                    <label for="num_serie_equipo" class="form-label">Número de serie</label>
                    <input type="text" class="form-control" placeholder="Ingrese número de serie del equipo"
                        id="num_serie_equipo" name="numero_serie" required>
                </div>
                <?php if($errors->has('numero_serie')): ?>
                <div class="alert alert-danger">
                    <?php echo e($errors->first('numero_serie')); ?>

                </div>
                <?php endif; ?>
                <!-- ID Tipo Equipo -->
                <div class="mb-3">
                    <label for="id_tipo_equipo" class="form-label">Tipo de equipo</label>
                    <select class="form-select" id="id_tipo_equipo" name="id_tipo_equipo" required>
                        <option value="" disabled selected>Selecciona un tipo de equipo</option>
                        <?php $__currentLoopData = $tipos_equipos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tipo_equipo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($tipo_equipo->id); ?>"><?php echo e($tipo_equipo->descripcion_tipo_equipo); ?></option>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <?php if($errors->has('id_tipo_equipo')): ?>
                <div class="alert alert-danger">
                    <?php echo e($errors->first('id_tipo_equipo')); ?>

                </div>
                <?php endif; ?>
                <!-- boton para agregar un nuevo tipo de equipo -->
                <div class="mb-3">
                    <a href="<?php echo e(route('tipo_equipos.create')); ?>" class="btn btn-primary">Agregar nuevo tipo de
                        equipo</a>

                    <!-- Nombre, Marca, Modelo, Color -->
                    <div class="row">
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="nombre" class="form-label">Nombre</label>
                                <input type="text" class="form-control" placeholder="Ingrese nombre del equipo"
                                    id="nombre" name="nombre_equipo" required>
                            </div>
                        </div>
                        <?php if($errors->has('nombre_equipo')): ?>
                        <div class="alert alert-danger">
                            <?php echo e($errors->first('nombre_equipo')); ?>

                        </div>
                        <?php endif; ?>


                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="marca" class="form-label">Marca</label>
                                <input type="text" class="form-control" placeholder="Ingrese marca del equipo"
                                    id="marca" name="marca_equipo" required>
                            </div>
                        </div>
                        <?php if($errors->has('marca_equipo')): ?>
                        <div class="alert alert-danger">
                            <?php echo e($errors->first('marca_equipo')); ?>

                        </div>
                        <?php endif; ?>
                    </div>

                    <div class="row">
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="modelo" class="form-label">Modelo</label>
                                <input type="text" class="form-control" placeholder="Ingrese modelo del equipo"
                                    id="modelo" name="modelo_equipo" required>
                            </div>
                        </div>
                        <?php if($errors->has('modelo_equipo')): ?>
                        <div class="alert alert-danger">
                            <?php echo e($errors->first('modelo_equipo')); ?>

                        </div>
                        <?php endif; ?>

                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="color" class="form-label">Color</label>
                                <input type="text" class="form-control" placeholder="Ingrese color del equipo"
                                    id="color" name="color_equipo" required>
                            </div>
                        </div>
                        <?php if($errors->has('color_equipo')): ?>
                        <div class="alert alert-danger">
                            <?php echo e($errors->first('color_equipo')); ?>

                        </div>
                        <?php endif; ?>
                    </div>

                    <!-- Estado -->
                    <div class="mb-3">
                        <label for="estado" class="form-label">Estado</label>
                        <select class="form-select" id="estado" name="estado_equipo" required>
                            <option value="" disabled selected>Selecciona el estado del equipo</option>
                            <option value="0">Disponible</option>
                            <option value="1">Prestado</option>
                        </select>
                    </div>
                    <?php if($errors->has('estado_equipo')): ?>
                    <div class="alert alert-danger">
                        <?php echo e($errors->first('estado_equipo')); ?>

                    </div>
                    <?php endif; ?>


                    <!-- Imagen de equipo -->
                    <div class="mb-3">
                        <label for="imagen" class="form-label">Imagen</label>
                        <input type="file" class="form-control" id="imagen" name="imagen_equipo" accept="image/*"
                            required>
                    </div>
                    <?php if($errors->has('imagen_equipo')): ?>
                    <div class="alert alert-danger">
                        <?php echo e($errors->first('imagen_equipo')); ?>

                    </div>
                    <?php endif; ?>



                    <!-- Botones Cancelar y Registrar -->
                    <div class="mb-3">
                        <a href="menu_principal.blade.php" class="btn btn-danger">Cancelar</a>
                        <button type="submit" class="btn btn-primary">Registrar</button>
                    </div>



                </div>
            </div>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\EDU_LOAN\resources\views/equipos/create.blade.php ENDPATH**/ ?>