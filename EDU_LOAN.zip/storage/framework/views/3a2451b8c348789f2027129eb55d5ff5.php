<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="<?php echo e(asset('../../css/estudiantes/create.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title'); ?>
<title>Registrar Estudiante</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <h2>Registro de Estudiantes</h2>
    <form action="<?php echo e(route('estudiantes.store')); ?>" method="post" id="estudianteForm" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <div class="row">
            <div class="col-3">
                <img src="../../resources/img/icon-estudiante.svg" alt="Icono de Estudiante" width="100" height="100">
            </div>
            <div class="col-9">

                <!-- ID Curso -->
                <div class="mb-3">
                    <label for="id_curso" class="form-label">Nombre del curso</label>
                    <select class="form-select" id="id_curso" name="id_curso" required>
                        <option value="" disabled selected>Selecciona un curso</option>
                        <?php $__currentLoopData = $cursos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $curso): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($curso->id); ?>"><?php echo e($curso->nombre_curso); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <a href="<?php echo e(route('cursos.create')); ?>" class="btn btn-success">Agregar Curso</a>
                <?php if($errors->has('id_curso')): ?>
                <div class="alert alert-danger">
                    <p>Debe seleccionar un curso</p>
                </div>
                <?php endif; ?>
                <!-- ID USUARIO -->
                <div class="mb-3">
                    <label for="id_usuario" class="form-label">Nombre de usuario</label>
                    <select class="form-select" id="id_usuario" name="id_usuario" required>
                        <option value="" disabled selected>Selecciona un usuario</option>
                        <?php $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usuario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($usuario->id); ?>"><?php echo e($usuario->username); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <?php if($errors->has('id_usuario')): ?>
                <div class="alert alert-danger">
                    <p>Debe seleccionar un usuario</p>
                </div>
                <?php endif; ?>

                <!-- boton para ir a agregar curso -->

                <!-- Nombre -->
                <div class="mb-3">
                    <label for="nombre" class="form-label">Nombre</label>
                    <input type="text" class="form-control" placeholder="Ingrese nombre" id="nombre"
                        name="nombre_estudiante" required>
                </div>
                <?php if($errors->has('nombre_estudiante')): ?>
                <div class="alert alert-danger">
                    <p>Debe ingresar un nombre</p>
                </div>
                <?php endif; ?>
                <!-- Apellido -->
                <div class="mb-3">
                    <label for="apellido" class="form-label">Apellido</label>
                    <input type="text" class="form-control" placeholder="Ingrese apellido" id=" apellido"
                        name="apellido_estudiante" required>
                </div>
                <?php if($errors->has('apellido_estudiante')): ?>
                <div class="alert alert-danger">
                    <p>Debe ingresar un apellido</p>
                </div>
                <?php endif; ?>

                <!-- Correo -->
                <div class=" mb-3">
                    <label for="correo" class="form-label">Correo Electrónico</label>
                    <input type="email" class="form-control" placeholder="Ingrese correo elecciorreo" id="correo"
                        name="correo_estudiante" required>
                </div>
                <?php if($errors->has('correo_estudiante')): ?>
                <div class="alert alert-danger">
                    <p>Debe ingresar un correo</p>
                </div>
                <?php endif; ?>

                <!-- Fecha Nacimiento -->
                <div class="mb-3">
                    <label for="fechaNacimiento" class="form-label">Fecha Nacimiento</label>
                    <input type="date" class="form-control" id="fechaNacimiento" name="fecha_nacimiento_estudiante"
                        required>
                </div>
                <?php if($errors->has('fecha_nacimiento_estudiante')): ?>
                <div class="alert alert-danger">
                    <p>Debe ingresar una fecha de nacimiento</p>
                </div>
                <?php endif; ?>


                <!-- Imagen -->
                <div class="mb-3">
                    <label for="imagen" class="form-label">Imagen</label>
                    <input type="file" class="form-control" id="imagen" name="imagen_estudiante" accept="image/*"
                        required>
                </div>


                <?php if($errors->has('imagen_estudiante')): ?>
                <div class="alert alert-danger">
                    <p><?php echo e($errors->first('imagen_estudiante')); ?></p>
                </div>
                <?php endif; ?>

                <!--Datos de bitacora-->
            <input type="hidden" id="tabla" name="tabla" value="estudiante">
            <input type="hidden" id="cambio" name="cambio" value="crear">

                <!-- Botón Cancelar -->
                <a href="<?php echo e(route('estudiantes.index')); ?>" class="btn btn-danger">Cancelar</a>
                <!-- Botón Registrar -->
                <button type="submit" class="btn btn-primary">Registrar</button>
            </div>
        </div>
    </form>
</div>
<br>
<br>
<br>
<br>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\EDU_LOAN\resources\views/estudiantes/create.blade.php ENDPATH**/ ?>