<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/ico" sizes="32x32" href="../resources/img/UNICAH_logo.ico" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('../resources/css/login/estilo_login.css')); ?>">
    <title>Login</title>
</head>

<body>
    <div class="login-box">
        <h1>Iniciar Sesión</h1>
        <?php if(session('error')): ?>
        <div class="alert alert-danger"><?php echo e(session('error')); ?></div>
        <?php endif; ?>

        <form action="<?php echo e(route('usuario.login')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label class="form-label" for="usuario">Usuario</label>
                <input type="text" name="username" id="username" class="form-control" placeholder="Usuario" required
                    autofocus>
            </div>
            <div class="form-group">
                <label class="form-label" for="contraseña">Contraseña</label>
                <input type="password" name="password" id="password" class="form-control" placeholder="Contraseña"
                    required>
            </div>

            <br>

            <button type="submit" class="btn btn-primary">Iniciar Sesión</button>
        </form>

    </div>
</body>

</html><?php /**PATH C:\xampp\htdocs\EDU_LOAN\resources\views/login/login.blade.php ENDPATH**/ ?>