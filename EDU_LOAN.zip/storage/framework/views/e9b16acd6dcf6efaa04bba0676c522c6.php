<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="<?php echo e(asset('../resources/css/usuarios/index.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title'); ?>
<title>crear curso</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="container">

    <form action="<?php echo e(route('roles.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>

        <div class="form-group">
            <label for="name">Nombre del Rol</label>
            <input type="text" class="form-control" id="name" name="descripcion"
                placeholder="Ingrese el nombre del rol">
        </div>
        <?php if($errors->has('descripcion')): ?>
        <span class="error text-danger"><?php echo e($errors->first('descripcion')); ?></span>
        <?php endif; ?>

        <!--Datos de bitacora-->
        <input type="hidden" id="tabla" name="tabla" value="rol_usuario">
        <input type="hidden" id="cambio" name="cambio" value="crear">
        <br>
        <button type="submit" class="btn btn-primary">Guardar</button>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\EDU_LOAN\resources\views/roles/create.blade.php ENDPATH**/ ?>