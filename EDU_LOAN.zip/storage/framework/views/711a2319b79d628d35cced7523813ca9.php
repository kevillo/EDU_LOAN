<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="<?php echo e(asset('../resources/css/usuarios/index.css')); ?>">
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>


<div class="container mt-5">
    <div class="d-flex flex-column flex-md-row justify-content-between">
        <h2 class="mb-3 mb-md-0">Usuarios</h2>
        <a href="<?php echo e(route('usuarios.create')); ?>" class="btn btn-success add">Agregar usuario</a>
    </div>
</div>


<!-- alertas -->
<?php if(session('Eliminado')): ?>
<div class="container mt-3">
    <div class="row justify-content-end">
        <div class="col-lg-4 col-md-6 col-sm-12">
            <div class="alert alert-success custom-alert" role="alert">
                <strong>¡Eliminado!</strong> <?php echo e(session('Eliminado')); ?>

            </div>
        </div>
    </div>
</div>
<?php endif; ?>




<?php if(session('Actualizado')): ?>
<div class="alert alert-success custom-alert" role="alert">
    <strong>¡Actualizado!</strong> <?php echo e(session('Actualizado')); ?>

</div>
<?php endif; ?>

<?php if(session('Creado')): ?>
<div class="alert alert-success custom-alert" role="alert">
    <strong>¡Creado!</strong> <?php echo e(session('Creado')); ?>

</div>
<?php endif; ?>


<!-- fin alertas -->

<main class="container mt-5">
    <div class="row row-cols-1 row-cols-md-2 row-cols-lg-3">
        <?php if(count($usuarios) > 0): ?>
        <?php $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usuario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <section>
            <!--inicio de card -->
            <div class="card custom-card ">
                <?php if($usuario->imagen): ?>
                <img style="max-height: 200px; width: auto; object-fit: cover; height: 100%;"
                    src="<?php echo e(asset('storage/' . $usuario->imagen)); ?>" class="card-img-top" alt="Banner de Publicación">
                <?php endif; ?>
                <div class="card-body custom-card-body">
                    <h5 class="card-title custom-card-title"><?php echo e($usuario->username); ?></h5>
                    <p class="card-text custom-card-text"><?php echo e($usuario->email); ?></p>
                    <div class="custom-btn-container ">
                        <div class="d-flex">
                            <a href="<?php echo e(route('usuarios.edit', $usuario->id)); ?>"
                                class="btn btn-success custom-btn edit">Editar</a>
                            <!-- Button trigger modal -->
                            <form action="<?php echo e(route('usuarios.destroy', $usuario->id)); ?>" class="form-delete"
                                method="POST">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-danger custom-btn delete">Eliminar</button>
                            </form>
                        </div>
                        <a href="<?php echo e(route('usuarios.show', $usuario->id)); ?>" class="btn btn-primary custom-btn show">Ver
                            detalles</a>
                    </div>
                </div>
            </div>
            <!--fin de card -->
        </section>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <?php else: ?>
        <p class="no-usuario-message">No hay ningún usuario.</p>
        <?php endif; ?>
    </div>
</main>

<?php $__env->startSection('js'); ?>
<script src="<?php echo e(asset('../resources/js/usuarios/index.js')); ?>"></script>
<script src="<?php echo e(asset('../resources/js/delete.js')); ?> "></script>

<?php $__env->stopSection(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\EDU_LOAN\resources\views/usuarios/index.blade.php ENDPATH**/ ?>