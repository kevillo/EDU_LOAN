<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="<?php echo e(asset('../resources/css/usuarios/create.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title'); ?>
<title>Registrar Usuario</title>
<?php $__env->stopSection(); ?>



<?php $__env->startSection('content'); ?>

<br><br><br><br>
<form action="<?php echo e(route('usuarios.store')); ?>" method="post">
    <?php echo csrf_field(); ?>
    <div class="row">
        <div class="col-3">
            <img src="../../resources/img/icon-usuario.png" alt="Icono de Usuario" width="100" height="100">
        </div>
        <div class="col-9">

            <!-- ID Rol Usuario -->
            <div class="mb-3">
                <label for="rol_usuario" class="form-label">Rol Usuario</label>
                <select class="form-select" id="rol_usuario" name="rol_usuario" required>
                    <option value="" disabled selected>Selecciona un rol de usuario</option>
                    <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rol): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($rol->id); ?>"><?php echo e($rol->descripcion); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </select>
            </div>
            <a href="<?php echo e(route('roles.create')); ?>" class="btn btn-success">Agregar Rol</a>
            <!-- Nombre -->
            <div class="mb-3">
                <label for="username" class="form-label">Nombre o Usuario</label>
                <input type="text" class="form-control" placeholder="Ingrese nombre" id="username" name="username"
                    required>
            </div>
            <?php if($errors->has('username')): ?>
            <div class="alert alert-danger">
                <?php echo e($errors->first('username')); ?>

            </div>
            <?php endif; ?>


            <!-- correo -->
            <div class="mb-3">
                <label for="email" class="form-label">Correo electronico</label>
                <input type="email" class="form-control" placeholder="Ingrese su correo" id="email" name="email"
                    required>
            </div>
            <?php if($errors->has('email')): ?>
            <div class="alert alert-danger">
                <?php echo e($errors->first('email')); ?>

            </div>
            <?php endif; ?>

            <!-- Contraseña -->
            <div class="mb-3">
                <label for="password" class="form-label">Contraseña</label>
                <input type="password" class="form-control" placeholder="Ingrese contraseña" id="password"
                    name="password" required>
            </div>
            <?php if($errors->has('password')): ?>
            <div class="alert alert-danger">
                <?php echo e($errors->first('password')); ?>

            </div>
            <?php endif; ?>

            <!-- Disponibilidad -->
            <div class="mb-3">
                <label for="is_available" class="form-label">Disponibilidad</label>
                <select class="form-select" id="is_available" name="is_available" required>
                    <option value="" disabled selected>Seleccione la disponibilidad</option>
                    <option value="1">Activo</option>
                    <option value="2">Inactivo</option>
                </select>
            </div>
            
            <!--Datos de bitacora-->
            <input type="hidden" id="tabla" name="tabla" value="usuario">
            <input type="hidden" id="cambio" name="cambio" value="crear">

            <!-- Botón Cancelar -->
            <a href="<?php echo e(route('usuarios.index')); ?>" class="btn btn-danger">Cancelar</a>
            <!-- Botón Registrar -->
            <button type="submit" class="btn btn-primary">Registrar</button>
            <br><br><br>
            <br>
            <br>
            <br>
        </div>
    </div>
</form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\EDU_LOAN\resources\views/usuarios/create.blade.php ENDPATH**/ ?>