


<?php $__env->startSection('title'); ?>
<title>Actualizar Estudiante</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container rounded shadow mt-1">
    <h2 class="p-3 text-center">Actualizacion de Estudiantes</h2>

    <form action="<?php echo e(route('estudiantes.update',$estudiante->id)); ?>" method="post" id="estudianteForm"
        enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="row">
            <div class="col-md-3">
                <img src="<?php echo e(asset('storage/' . $estudiante->imagen_estudiante)); ?>" class="img img-fluid card-img"
                    alt="Icono de Estudiante" width="100" height="100">
            </div>
            <div class="col-md-9">

                <!-- ID Curso -->
                <div class="mb-3">
                    <label for="id_curso" class="form-label">Nombre del curso</label>
                    <select class="form-select" id="id_curso" name="id_curso" required>
                        <option value="" disabled selected>Selecciona un curso</option>
                        <?php $__currentLoopData = $cursos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $curso): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($curso->id); ?>"><?php echo e($curso->nombre_curso); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <a href="<?php echo e(route('cursos.create')); ?>" class="btn btn-success mt-2">Agregar Curso</a>
                    <?php if($errors->has('id_curso')): ?>
                    <div class="alert alert-danger mt-2">
                        <p>Debe seleccionar un curso</p>
                    </div>
                    <?php endif; ?>
                </div>

                <!-- ID USUARIO -->
                <div class="mb-3">
                    <label for="id_usuario" class="form-label">Nombre de usuario</label>
                    <select class="form-select" id="id_usuario" name="id_usuario" required>
                        <option value="" disabled selected>Selecciona un usuario</option>
                        <?php $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usuario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($usuario->id); ?>"><?php echo e($usuario->username); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php if($errors->has('id_usuario')): ?>
                    <div class="alert alert-danger mt-2">
                        <p>Debe seleccionar un usuario</p>
                    </div>
                    <?php endif; ?>
                </div>

                <!-- Nombre -->
                <div class="mb-3">
                    <label for="nombre" class="form-label">Nombre</label>
                    <input type="text" class="form-control" placeholder="Ingrese nombre" id="nombre"
                        value="<?php echo e($estudiante->nombre_estudiante); ?>" name="nombre_estudiante" required>
                    <?php if($errors->has('nombre_estudiante')): ?>
                    <div class="alert alert-danger mt-2">
                        <p>Debe ingresar un nombre</p>
                    </div>
                    <?php endif; ?>
                </div>

                <!-- Apellido -->
                <div class="mb-3">
                    <label for="apellido" class="form-label">Apellido</label>
                    <input type="text" class="form-control" placeholder="Ingrese apellido" id="apellido"
                        name="apellido_estudiante" value="<?php echo e($estudiante->apellido_estudiante); ?>" required>
                    <?php if($errors->has('apellido_estudiante')): ?>
                    <div class="alert alert-danger mt-2">
                        <p>Debe ingresar un apellido</p>
                    </div>
                    <?php endif; ?>
                </div>

                <!-- Correo -->
                <div class="mb-3">
                    <label for="correo" class="form-label">Correo Electrónico</label>
                    <input type="email" class="form-control" placeholder="Ingrese correo electrónico" id="correo"
                        name="correo_estudiante" value="<?php echo e($estudiante->correo_estudiante); ?>" required>
                    <?php if($errors->has('correo_estudiante')): ?>
                    <div class="alert alert-danger mt-2">
                        <p>Debe ingresar un correo electrónico válido</p>
                    </div>
                    <?php endif; ?>
                </div>

                <!-- Fecha Nacimiento -->
                <div class="mb-3">
                    <label for="fechaNacimiento" class="form-label">Fecha de Nacimiento</label>
                    <input type="date" class="form-control" id="fechaNacimiento" name="fecha_nacimiento_estudiante"
                        value="<?php echo e($estudiante->fecha_nacimiento_estudiante); ?>" required>
                    <?php if($errors->has('fecha_nacimiento_estudiante')): ?>
                    <div class="alert alert-danger mt-2">
                        <p>Debe ingresar una fecha de nacimiento</p>
                    </div>
                    <?php endif; ?>
                </div>

                <!-- Imagen -->
                <div class="mb-3">
                    <label for="imagen" class="form-label">Imagen</label>
                    <input type="file" class="form-control" id="imagen" name="imagen_estudiante" accept="image/*"
                        required>
                    <?php if($errors->has('imagen_estudiante')): ?>
                    <div class="alert alert-danger mt-2">
                        <p><?php echo e($errors->first('imagen_estudiante')); ?></p>
                    </div>
                    <?php endif; ?>
                </div>

                <!-- Botones -->
                <div class="mb-3">
                    <a href="<?php echo e(route('estudiantes.index')); ?>" class="btn btn-secondary">Cancelar</a>
                    <button type="submit" class="btn btn-primary">Actualizar</button>
                </div>
            </div>
        </div>
    </form>


</div>
<br><br><br><br><br>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\EDU_LOAN\resources\views/estudiantes/edit.blade.php ENDPATH**/ ?>