<?php $__env->startSection('css'); ?>
 <link rel="stylesheet" href="<?php echo e(asset('../resources/css/consultas/consulta.css')); ?>">   
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title'); ?>
<title>Reportes</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h2 class="mb-0">Reporte de Usuarios</h2> 
            <a href="<?php echo e(route('consultas.pdf')); ?>" class="btn btn-success" target="_blank">Descargar PDF</a>
        </div>
        <table class="table table-bordered text-center table-container">
            <thead>
                <tr>
                    <th>Rol Usuario</th>
                    <th>Nombre o usuario</th>
                    <th>Correo electrónico</th>
                    <th>Disponibilidad</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($user->id_rol_user); ?></td>
                        <td><?php echo e($user->username); ?></td>
                        <td><?php echo e($user->email); ?></td>
                        <td><?php echo e($user->is_available); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\EDU_LOAN\resources\views/consultas/reportes.blade.php ENDPATH**/ ?>