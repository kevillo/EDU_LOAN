


<?php $__env->startSection('title'); ?>
<title>Registro de los tipos de equipo</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container mt-">
    <form action="<?php echo e(route('tipo_equipos.store')); ?>" method="post">
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <label for="descripcion_tipo_equipo">Tipo de equipo</label>
            <input type="text" class="form-control" id="descripcion_tipo_equipo" name="descripcion_tipo_equipo"
                placeholder="Ingrese el tipo de equipo">
        </div>
        <br>
        <button type="submit" class="btn btn-primary">Guardar</button>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\EDU_LOAN\resources\views/tipo_equipos/create.blade.php ENDPATH**/ ?>