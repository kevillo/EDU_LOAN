<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/estudiantes/create.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title'); ?>
<title>Detalles del Estudiante</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container mt-5 rounded shadow w-50">
    <div class="row">
        <div class="col-md-6">

            <?php if($estudiante->imagen_estudiante): ?>
            <img src="<?php echo e(asset('storage/' . $estudiante->imagen_estudiante)); ?>" alt="Imagen del Estudiante"
                class="card-img img-fluid  rounded  p-3">
            <?php else: ?>
            <p>No hay imagen disponible</p>
            <?php endif; ?>
        </div>
        <div class="col-md-6  d-flex flex-column justify-content-center   align-items-sm-center ">
            <h2 class="p-3">Detalles del Estudiante</h2>
            <p><strong>Usuario asignado:</strong> <?php echo e($usuarios->username); ?></p>
            <p><strong>Nombre:</strong> <?php echo e($estudiante->nombre_estudiante); ?></p>
            <p><strong>Apellido:</strong> <?php echo e($estudiante->apellido_estudiante); ?></p>
            <p><strong>Correo Electrónico:</strong> <?php echo e($estudiante->correo_estudiante); ?></p>
            <p><strong>Fecha de Nacimiento:</strong> <?php echo e($estudiante->fecha_nacimiento_estudiante); ?></p>
            <p><strong>Curso:</strong> <?php echo e($cursos->nombre_curso); ?></p>


            <div class=" p-2  ">
                <a href="<?php echo e(route('estudiantes.index')); ?>" class="btn btn-danger">Volver</a>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\EDU_LOAN\resources\views/estudiantes/show.blade.php ENDPATH**/ ?>