<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/ico" sizes="32x32" href="../resources/img/UNICAH_logo.ico" />
    <link rel="stylesheet" href="<?php echo e(asset('../resources/css/app.css')); ?>">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <?php echo $__env->yieldContent('css'); ?>
    <?php echo $__env->yieldContent('title'); ?>


</head>

<body>
    <nav class="navbar navbar-expand-lg">

        <a href="<?php echo e(route('usuarios.main')); ?>" class="navbar-custom-brand">EDU LOAN</a>
        <button class="navbar-toggler  " type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
            aria-controls="navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="nav-links navbar-nav mt-0">
                <?php if(Auth::check() && Auth::user()->id_rol_user == 1): ?>
                <li class="nav-item"><a href="<?php echo e(route('usuarios.index')); ?>" class="nav-link">Usuarios</a></li>
                <li class="nav-item"><a href="<?php echo e(route('equipos.index')); ?>" class="nav-link">Equipos</a></li>
                <li class="nav-item"><a href="<?php echo e(route('estudiantes.index')); ?>" class="nav-link">Estudiantes</a></li>
                <li class="nav-item"><a href="<?php echo e(route('consultas.index')); ?>" class="nav-link">Consultas</a></li>
                <li class="nav-item"><a href="#" class="nav-link">Préstamos</a></li>
                <li class="nav-item"><a href="<?php echo e(route('bitacora.bitacora')); ?>" class="nav-link">Bitacora</a></li>
                <?php else: ?>
                <li class="nav-item"><a href="#" class="nav-link">Préstamos</a></li>
                <?php endif; ?>
            </ul>
            <ul class="nav-links navbar-nav mt-0 ms-auto">
                <li class="nav-item"><a href="<?php echo e(route('logout')); ?>" class="nav-link">Cerrar Sesión</a></li>
            </ul>

        </div>
    </nav>
    <article>
        <?php echo $__env->yieldContent('content'); ?>
    </article>
    <footer class="text-center">
        <p>&copy; 2023 EDU LOAN. Todos los derechos reservados.</p>
    </footer>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/2.1.2/sweetalert.min.js"></script>

    <?php echo $__env->yieldContent('js'); ?>
</body>

</html><?php /**PATH C:\xampp\htdocs\EDU_LOAN\resources\views/layouts/app.blade.php ENDPATH**/ ?>